package com.firelamp.neo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import kotlinx.coroutines.*

private val Bg = Color(0xFF090812)
private val Panel = Color(0xFF171426)
private val Purple = Color(0xFF9B72FF)
private val Muted = Color(0xFFAAA4BE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FireLampApp() }
    }
}

@Composable fun FireLampApp() {
    var tab by remember { mutableIntStateOf(0) }
    var power by remember { mutableStateOf(false) }
    var brightness by remember { mutableFloatStateOf(72f) }
    var speed by remember { mutableFloatStateOf(55f) }
    var hue by remember { mutableFloatStateOf(270f) }
    var selected by remember { mutableStateOf("Радуга") }
    var ip by remember { mutableStateOf("192.168.1.40") }
    var port by remember { mutableStateOf("8888") }
    var status by remember { mutableStateOf("Не проверено") }
    val effects = listOf("Конфетти","Огонь","Водопад","Радуга","Радуга вертикальная","Радуга диагональная","Смена цвета","Безумие 3D","Облака 3D","Лава 3D","Плазма 3D","Радуга 3D","Павлин 3D","Зебра 3D","Лес 3D","Океан 3D","Цвет","Снегопад","Метель","Звездопад","Матрица","Светлячки","Пейнтбол","Аквариум","Пульс","Комета","Белый свет","Шарики","Призмата","Облако в банке","Гроза в банке","Осадки","Цветной дождь","Часы","Бегущая строка")
    MaterialTheme(colorScheme = darkColorScheme(primary=Purple, background=Bg, surface=Panel)) {
        Scaffold(containerColor=Bg, bottomBar={
            NavigationBar(containerColor=Panel, contentColor=Muted) {
                listOf("Главная","Эффекты","Настройки").forEachIndexed { i, label ->
                    NavigationBarItem(selected=tab==i,onClick={tab=i},icon={
                        Icon(when(i){0->Icons.Default.Home;1->Icons.Default.AutoAwesome;else->Icons.Default.Settings},null)
                    },label={Text(label)}, colors=NavigationBarItemDefaults.colors(selectedIconColor=Purple,selectedTextColor=Purple,indicatorColor=Purple.copy(alpha=.15f)))
                }
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal=20.dp)) {
                Spacer(Modifier.height(22.dp))
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("FIRELAMP", color=Muted, fontSize=12.sp, letterSpacing=3.sp, fontWeight=FontWeight.Bold)
                        Text(when(tab){0->"Управление";1->"Эффекты";else->"Настройки"}, color=Color.White, fontSize=28.sp, fontWeight=FontWeight.Bold)
                    }
                    Surface(shape=RoundedCornerShape(50),color=Panel) {
                        Row(Modifier.padding(horizontal=12.dp, vertical=8.dp),verticalAlignment=Alignment.CenterVertically) {
                            Box(Modifier.size(7.dp).background(if(status=="Подключён") Color(0xFF48D597) else Purple, CircleShape))
                            Spacer(Modifier.width(7.dp)); Text(status, color=Muted, fontSize=11.sp)
                        }
                    }
                }
                Spacer(Modifier.height(22.dp))
                when(tab) {
                    0 -> {
                        Surface(Modifier.fillMaxWidth(),shape=RoundedCornerShape(28.dp),color=Panel) {
                            Column(Modifier.padding(20.dp)) {
                                Row(verticalAlignment=Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text("СВЕТОВОЙ ЭФФЕКТ",color=Muted,fontSize=11.sp,letterSpacing=1.5.sp)
                                        Text(selected,color=Color.White,fontSize=23.sp,fontWeight=FontWeight.SemiBold)
                                    }
                                    Switch(checked=power,onCheckedChange={power=it})
                                }
                                Box(Modifier.fillMaxWidth().height(150.dp),contentAlignment=Alignment.Center) {
                                    Box(Modifier.size(126.dp).shadow(35.dp, CircleShape, ambientColor=Color.hsv(hue, .8f, 1f), spotColor=Color.hsv(hue,.8f,1f)).background(Brush.radialGradient(listOf(Color.hsv(hue,.85f,1f).copy(alpha=.35f),Color.Transparent)),CircleShape))
                                    Box(Modifier.size(84.dp).border(1.dp,Color.hsv(hue,.75f,1f).copy(alpha=.7f),CircleShape).background(Color.hsv(hue,.8f,.18f),CircleShape),contentAlignment=Alignment.Center) {
                                        Icon(Icons.Default.Lightbulb, null, tint=Color.hsv(hue,.55f,1f), modifier=Modifier.size(38.dp))
                                    }
                                }
                                Text("Яркость  ${brightness.toInt()}%",color=Color.White,fontWeight=FontWeight.Medium)
                                Slider(value=brightness,onValueChange={brightness=it},valueRange=1f..100f)
                                Text("Скорость  ${speed.toInt()}%",color=Color.White,fontWeight=FontWeight.Medium)
                                Slider(value=speed,onValueChange={speed=it},valueRange=1f..100f)
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        Text("БЫСТРЫЙ ВЫБОР",color=Muted,fontSize=11.sp,letterSpacing=1.5.sp,fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                            listOf("Огонь","Радуга","Матрица").forEach { name ->
                                Surface(Modifier.weight(1f).clickable { selected=name; tab=1 },shape=RoundedCornerShape(16.dp),color=Panel) {
                                    Column(Modifier.padding(13.dp)) {
                                        Icon(Icons.Default.AutoAwesome,null,tint=Purple)
                                        Spacer(Modifier.height(8.dp)); Text(name,color=Color.White,fontSize=13.sp,fontWeight=FontWeight.Medium)
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        Text("ЦВЕТ",color=Muted,fontSize=11.sp,letterSpacing=1.5.sp,fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Slider(value=hue,onValueChange={hue=it},valueRange=0f..360f,colors=SliderDefaults.colors(thumbColor=Color.hsv(hue,1f,1f),activeTrackColor=Purple))
                    }
                    1 -> {
                        Text("${effects.size} встроенных режимов",color=Muted,fontSize=13.sp)
                        Spacer(Modifier.height(12.dp))
                        effects.chunked(2).forEach { pair ->
                            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                                pair.forEach { name ->
                                    Surface(Modifier.weight(1f).padding(bottom=10.dp).clickable { selected=name; tab=0 },shape=RoundedCornerShape(18.dp),color=if(selected==name) Purple.copy(alpha=.22f) else Panel, border=BorderStroke(1.dp,if(selected==name) Purple.copy(alpha=.8f) else Color.Transparent)) {
                                        Column(Modifier.padding(14.dp)) {
                                            Icon(Icons.Default.Waves,null,tint=Purple)
                                            Spacer(Modifier.height(10.dp))
                                            Text(name,color=Color.White,fontWeight=FontWeight.Medium,fontSize=14.sp,minLines=2)
                                            Text(if(selected==name)"Выбран" else "Выбрать",color=Muted,fontSize=11.sp)
                                        }
                                    }
                                }
                                if(pair.size==1) Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                    else -> {
                        Surface(Modifier.fillMaxWidth(),shape=RoundedCornerShape(22.dp),color=Panel) {
                            Column(Modifier.padding(18.dp)) {
                                Text("ПОДКЛЮЧЕНИЕ",color=Muted,fontSize=11.sp,letterSpacing=1.5.sp)
                                Spacer(Modifier.height(14.dp))
                                OutlinedTextField(value=ip,onValueChange={ip=it},label={Text("IP-адрес")},singleLine=true,modifier=Modifier.fillMaxWidth())
                                Spacer(Modifier.height(10.dp))
                                OutlinedTextField(value=port,onValueChange={port=it},label={Text("UDP-порт")},singleLine=true,modifier=Modifier.fillMaxWidth())
                                Spacer(Modifier.height(14.dp))
                                Button(onClick={ status="Ожидает проверки протокола" },modifier=Modifier.fillMaxWidth()) { Text("Проверить подключение") }
                                Text("Сохранённый адрес: $ip:$port",color=Muted,fontSize=12.sp)
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        Text("FireLamp Neo • интерфейс-проект 1.0",color=Muted,fontSize=12.sp)
                    }
                }
                Spacer(Modifier.height(28.dp))
            }
        }
    }
}
